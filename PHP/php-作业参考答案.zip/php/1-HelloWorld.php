<?php
function helloWorld()
{
    return "Hello, World!";
}