<!DOCTYPE html>
<html lang="zh-cn">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>首页</title>
  <link rel="stylesheet" href="style/main.css">
</head>
<body>
  <header>
    <div class="wrapper">
      <nav>
        <a href="user/login.php">登录</a>
      </nav>
    </div>
  </header>
  <?php
   include 'user/common/footer.php'
  ?>
</body>

</html>