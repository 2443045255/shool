<footer>
  <p>Copy Right © 湄洲湾职业技术学院 2024-2025</p>
</footer>