<header>
  <div class="wrapper">
    <div class="title">用户中心</div>
    <div class="username">
      <span>用户名：</span>
      <span class="getvalue">XXX</span>
    </div>
  </div>
</header>